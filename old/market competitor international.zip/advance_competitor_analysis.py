from typing import Dict, List, Optional
import asyncio
from groq import Groq
import json
import os
from dotenv import load_dotenv
from tavily import TavilyClient
from datetime import datetime
from PESTEL_Analysis import BaseAnalyst

user_startup = "100xEngineering"
data_folder = f'data_{user_startup}'

class MarketingStrategyAnalyst(BaseAnalyst):
    analysis_prompt = """Provide a markdown-formatted analysis focusing on:
        ## Marketing Strategy
        1. Marketing Channels
        2. Partnership Analysis
        3. Content Strategy
           - Social Media, Webinars, Podcasts, Blog content...
        4. Brand Positioning"""
    research_prompt = f'Competitive analysis of {user_startup} and its competitors'

class KeywordSEOAnalyst(BaseAnalyst):
    analysis_prompt = """Provide a markdown-formatted analysis focusing on:
        ## SEO and Digital Presence
        1. Keyword Analysis
           - Top ranking keywords
           - Search volume
        2. SEO Strategy
           - Content optimization
           - Technical SEO
        3. Social Media Presence
           - Platform analysis
           - Engagement metrics"""
    research_prompt = f'Competitive analysis of {user_startup} and its competitors'

class ValuationAnalyst(BaseAnalyst):
    analysis_prompt = """Provide a markdown-formatted analysis focusing on:
        ## Company Valuations
        1. Funding History
        2. Investment Rounds
        3. Key Investors
        4. Cap Table Analysis
        5. Current Valuation"""
    research_prompt = f'Competitive analysis of {user_startup} and its competitors'



class RecentUpdatesAnalyst(BaseAnalyst):
    analysis_prompt = """Provide a markdown-formatted analysis focusing on:
        ## Recent Company Updates
        1. Latest News
        2. Product Releases
        3. Major Milestones
        4. Company Achievements
        5. Market Impact"""
    research_prompt = f'Competitive analysis of {user_startup} and its competitors'

class FinancialAnalyst(BaseAnalyst):
    analysis_prompt = """Provide a markdown-formatted analysis focusing on:
        ## Financial Analysis
        1. Revenue Metrics
           - Revenue growth
           - Revenue streams
           - Key financial indicators
        2. Profitability Analysis
           - Margins, Operating costs, Profitability trends
        3. Financial Health
           - Burn rate, Cash reserves, debt structure
        4. Unit Economics
           - Customer acquisition cost, Lifetime value, 
           - Other key metrics"""
    research_prompt = f'Competitive analysis of {user_startup} and its competitors'

async def analyze_competitor(company_name: str, industry: str) -> str:
    try:
        analysts = {

            "Marketing Strategy": MarketingStrategyAnalyst(),
            "Keyword/SEO": KeywordSEOAnalyst(),
            "Valuations": ValuationAnalyst(),
            "Recent Updates": RecentUpdatesAnalyst(),
            "Financial Analysis": FinancialAnalyst()
        }

        results = await asyncio.gather(*[
            asyncio.to_thread(analyst.analyze, company_name, industry)
            for analyst in analysts.values()
        ])

        output_dir = data_folder
        os.makedirs(output_dir, exist_ok=True)

        report_content = [
            f"# Competitor Analysis: {company_name}",
            f"\n## Industry: {industry}",
            f"\n## Analysis Date: {datetime.now().strftime('%Y-%m-%d')}",
            "\n## Table of Contents\n"
        ]

        for (section_name, _), result in zip(analysts.items(), results):
            report_content.append(f"\n## {section_name}\n")
            report_content.append(result['analysis'])
            report_content.append("\n### Sources")
            for source in result['sources']:
                report_content.append(f"- [{source['url']}]({source['url']})")

        report_path = os.path.join(output_dir, "adv_competitor.md")
        with open(report_path, "w", encoding='utf-8') as f:
            f.write("\n".join(report_content))

        return report_path

    except Exception as e:
        print(f"Analysis error: {e}")
        return ""

if __name__ == "__main__":
    company = input("Enter company name to analyze: ")
    industry = input("Enter industry: ")
    
    result = asyncio.run(analyze_competitor(company, industry))
    if result:
        print(f"Analysis saved to: {result}")
    else:
        print("Analysis failed")