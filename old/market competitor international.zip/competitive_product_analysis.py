
from typing import Dict, List, Optional
import asyncio
from groq import Groq
import json
import os
from dotenv import load_dotenv
from tavily import TavilyClient
from datetime import datetime
from PESTEL_Analysis import BaseAnalyst

user_startup = "100xEngineering"
data_folder = f'data_{user_startup}'

class CompetitiveProductAnalyst(BaseAnalyst):
    analysis_prompt = """Provide a markdown-formatted analysis focusing on:
        ## Product Analysis
        1. Core Product Features
           - Key functionalities
           - Technical capabilities
           - Platform/Technology stack
        2. Product Market Fit
           - Target audience
           - Use cases
           - Customer segments
        3. Product Development
           - Release cycles
           - Innovation roadmap
           - Recent updates
        4. User Experience
           - Interface design
           - Ease of use
           - Customer feedback"""
    research_prompt = f'Competitive Produt analysis of {user_startup} and its competitors'

class PricingStrategyAnalyst(BaseAnalyst):
    analysis_prompt = """Provide a markdown-formatted analysis focusing on:
        ## Pricing Strategy
        1. Pricing Models
           - Subscription tiers
           - One-time purchases
           - Enterprise pricing
        2. Price Comparison
           - Market positioning
           - Value proposition
        3. Revenue Model
           - Monetization strategy
           - Payment structures
        4. Promotional Strategy
           - Discounts
           - Trials
           - Special offers"""
    research_prompt = f'Pricing analysis of {user_startup} and its competitors'

class CompetitiveAdvantageAnalyst(BaseAnalyst):
    analysis_prompt = """Provide a markdown-formatted analysis focusing on:
        ## Competitive Advantages
        1. Unique Selling Points
           - Key differentiators
           - Proprietary technology
        2. Market Position
           - Industry ranking
           - Market share
        3. Brand Strength
           - Brand recognition
           - Customer loyalty
        4. Innovation Focus
           - R&D investments
           - Patents and IP"""
    research_prompt = f' competitive analysis of {user_startup} and its competitors'

async def analyze_competitor(company_name: str, industry: str) -> str:
    try:
        analysts = {
            "Product Analysis": CompetitiveProductAnalyst(),
            "Pricing Strategy": PricingStrategyAnalyst(),
            "Competitive Advantages": CompetitiveAdvantageAnalyst()
        }

        results = await asyncio.gather(*[
            asyncio.to_thread(analyst.analyze, company_name, industry)
            for analyst in analysts.values()
        ])

        output_dir = data_folder
        os.makedirs(output_dir, exist_ok=True)

        report_content = [
            f"# Competitor Analysis: {company_name}",
            f"\n## Industry: {industry}",
            f"\n## Analysis Date: {datetime.now().strftime('%Y-%m-%d')}",
            "\n## Table of Contents\n"
        ]

        for (section_name, _), result in zip(analysts.items(), results):
            report_content.append(f"\n## {section_name}\n")
            report_content.append(result['analysis'])
            report_content.append("\n### Sources")
            for source in result['sources']:
                report_content.append(f"- [{source['url']}]({source['url']})")

        report_path = os.path.join(output_dir, f"competitor_analysis.md")
        with open(report_path, "w", encoding='utf-8') as f:
            f.write("\n".join(report_content))

        return report_path

    except Exception as e:
        print(f"Analysis error: {e}")
        return ""

if __name__ == "__main__":
    company = input("Enter company name to analyze: ")
    industry = input("Enter industry: ")
    
    result = asyncio.run(analyze_competitor(company, industry))
    if result:
        print(f"Analysis saved to: {result}")
    else:
        print("Analysis failed")