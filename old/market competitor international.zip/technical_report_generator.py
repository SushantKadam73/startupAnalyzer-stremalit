import os
from google.generativeai import GenerativeModel, configure
from typing import List
from datetime import datetime
import markdown
import pdfkit

user_startup = "100xEngineering"
# country = "Europe"
# industry = "flavoured beer" 
# Constants
INPUT_FOLDER = f'data_{user_startup}'
OUTPUT_FOLDER = f'{INPUT_FOLDER}/Reports'
REPORT_TYPES = {
    "Market_Research": ["PESTEL_report.md", "adv_market.md"],
    "Competitive_Research": ["competitor_analysis.md", "adv_competitor.md"],
    "International_Market": ["international_market.md"]
}

class TechnicalReportGenerator:
    def __init__(self):
        # Configure Gemini
        configure(api_key=os.getenv('GOOGLE_API_KEY'))
        self.model = GenerativeModel('gemini-1.5-flash')
        # Create output directory if it doesn't exist
        os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    
    def read_source_files(self, filenames: List[str]) -> str:
        """Read and combine content from source files that exist"""
        combined_content = []
        found_files = False
        
        for filename in filenames:
            filepath = os.path.join(INPUT_FOLDER, filename)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                    combined_content.append(f"--- Content from {filename} ---\n{content}\n")
                    found_files = True
            except FileNotFoundError:
                print(f"Info: Optional file not found - {filepath}")
        
        return "\n".join(combined_content) if found_files else ""

    def generate_report(self, content: str, report_type: str) -> str:
        """Generate formatted report using Gemini 1.5 Flash"""
        prompt = f"""You are a professional business analyst and a technical writer. Make a detailed report on  
        {report_type} using the resources provided. also use tables, pictures, grpahs, to analysis report using the following source content. The report should contain  at least one orderd or unordered list. use numberes, %, etc whereever possible. 

        Source Content:
        {content}.

        Please provide the report in markdown format.
        """

        try:
            response = self.model.generate_content(
                prompt,
                generation_config={
                    "temperature": 0.7,
                    "top_p": 0.8,
                    "top_k": 40,
                    "max_output_tokens": 8000,
                }
            )
            return response.text
        except Exception as e:
            print(f"Error generating report: {e}")
            return ""

    def markdown_to_pdf(self, markdown_content: str, output_path: str) -> str:
        """Convert markdown content to PDF"""
        try:
            # Convert markdown to HTML
            html_content = markdown.markdown(
                markdown_content,
                extensions=['tables', 'fenced_code', 'toc']
            )
            
            # Add CSS for better formatting
            styled_html = f"""
            <html>
            <head>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 40px; }}
                    h1 {{ color: #2c3e50; }}
                    h2 {{ color: #34495e; border-bottom: 1px solid #eee; }}
                    table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
                    th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                    th {{ background-color: #f5f5f5; }}
                    blockquote {{ border-left: 4px solid #ccc; margin: 0; padding-left: 16px; }}
                    code {{ background: #f8f9fa; padding: 2px 4px; }}
                </style>
            </head>
            <body>
                {html_content}
            </body>
            </html>
            """
            
            # Convert HTML to PDF
            pdfkit.from_string(styled_html, output_path)
            return output_path
        except Exception as e:
            print(f"Error converting to PDF: {e}")
            return ""

    def save_report(self, content: str, report_type: str) -> str:
        """Save the generated report as PDF"""
        filename = f"{report_type}.pdf"
        filepath = os.path.join(OUTPUT_FOLDER, filename)
        
        # Save markdown content first (for reference)
        md_filepath = os.path.join(OUTPUT_FOLDER, f"{report_type}.md")
        with open(md_filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        # Convert to PDF
        return self.markdown_to_pdf(content, filepath)

    def process_all_reports(self):
        """Process reports where source files are available"""
        for report_type, source_files in REPORT_TYPES.items():
            print(f"\nProcessing {report_type} report...")
            
            # Read source content
            content = self.read_source_files(source_files)
            if not content:
                print(f"Skipping {report_type} report - no source files available")
                continue
            
            # Generate and save report
            print(f"Generating {report_type} report...")
            report_content = self.generate_report(content, report_type)
            
            if report_content:
                output_file = self.save_report(report_content, report_type)
                print(f"Report saved to: {output_file}")
            else:
                print(f"Failed to generate {report_type} report")

def main():
    generator = TechnicalReportGenerator()
    generator.process_all_reports()

if __name__ == "__main__":
    main()